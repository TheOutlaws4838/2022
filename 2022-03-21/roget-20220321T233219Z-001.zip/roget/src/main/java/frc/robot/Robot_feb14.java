// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.cameraserver.CameraServer;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.motorcontrol.MotorControllerGroup;
import edu.wpi.first.wpilibj.motorcontrol.PWMSparkMax;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the TimedRobot
 * documentation.
 * If you change the name of this class or
 * the package after creating this project, you must also update the manifest
 * file in the resource
 * directory.
 */
public class Robot_feb14 extends TimedRobot {
  private final PWMSparkMax m_rightDrive0 = new PWMSparkMax(0);
  private final PWMSparkMax m_rightDrive1 = new PWMSparkMax(1);
  private final PWMSparkMax m_leftDrive0 = new PWMSparkMax(2);
  private final PWMSparkMax m_leftDrive1 = new PWMSparkMax(3);
  private final PWMSparkMax m_elevator1 = new PWMSparkMax(6);
  /* We havent used 4 */
  private final PWMSparkMax m_intake = new PWMSparkMax(7);
  private final PWMSparkMax m_ramp = new PWMSparkMax(5);

  private final MotorControllerGroup m_leftDrive = new MotorControllerGroup(m_leftDrive0, m_leftDrive1);
  private final MotorControllerGroup m_rightDrive = new MotorControllerGroup(m_rightDrive0, m_rightDrive1);
  private final DifferentialDrive m_robotDrive = new DifferentialDrive(m_leftDrive, m_rightDrive);
  private final XboxController m_joystick = new XboxController(0);
  private final Timer m_timer = new Timer();
  private boolean m_is_backwards = false;
  private boolean m_is_turbo = false;
  private boolean m_is_ramping = false;

  private IntakeMode m_intakeMode = IntakeMode.NOTHING;

  private enum IntakeMode {
    INTAKING,
    OUTTAKING,
    NOTHING
  }

  /**
   * This function is run when the robot is first started up and
   * should be used for any initialization code.
   */
  @Override
  public void robotInit() {
    // We need to invert one side of the drivetrain so that positive voltages
    // result in both sides moving forward. Depending on how your robot's
    // gearbox is constructed, you might have to invert the left side instead.
    m_rightDrive.setInverted(true);
    CameraServer.startAutomaticCapture(0);
    CameraServer.startAutomaticCapture(1);

  }

  /** This function is run once each time the robot enters autonomous mode. */
  @Override
  public void autonomousInit() {
    m_timer.reset();
    m_timer.start();
  }

  /** This function is called periodically during autonomous. */
  @Override
  public void autonomousPeriodic() {
    // Drive for 2 seconds
    if (m_timer.get() < 2.0) {
      m_robotDrive.arcadeDrive(0.5, 0.0); // drive forwards half speed
    } else {
      m_robotDrive.stopMotor(); // stop robot
    }
  }

  /**
   * This function is called once each time the robot enters teleoperated mode.
   */
  @Override
  public void teleopInit() {
  }

  /** This function is called periodically during teleoperated mode. */
  @Override
  public void teleopPeriodic() {
    // elevator: shoulder buttons (lb/rb) - motor 7
    // drive: tank controls - Left: Motor 0/1, Right: Motor 2,3
    // reverse: start
    // top door: a
    // intake: y
    // reverse intake: x
    // ramp: b
    // back button: turbo
    if (m_joystick.getRightBumper()) {
      m_elevator1.set(-.5);
    } else if (m_joystick.getLeftBumper()) {
      m_elevator1.set(.5);
    } else {
      m_elevator1.set(0);
    }

    System.out.println("Intake mode:" + m_intakeMode);

    if (m_intakeMode == IntakeMode.NOTHING) {

      if (m_joystick.getXButtonPressed()) {
        m_intakeMode = IntakeMode.OUTTAKING;
      } else if (m_joystick.getYButtonPressed()) {
        m_intakeMode = IntakeMode.INTAKING;
      }
    } else if (m_intakeMode == IntakeMode.INTAKING) {

      if (m_joystick.getXButtonPressed()) {
        m_intakeMode = IntakeMode.OUTTAKING;

      } else if (m_joystick.getYButtonPressed()) {
        m_intakeMode = IntakeMode.NOTHING;

      }
    } else if (m_intakeMode == IntakeMode.OUTTAKING) {

      if (m_joystick.getXButtonPressed()) {
        m_intakeMode = IntakeMode.NOTHING;

      } else if (m_joystick.getYButtonPressed()) {
        m_intakeMode = IntakeMode.INTAKING;
      }
    }

    if (m_intakeMode == IntakeMode.INTAKING) {
      m_intake.set(1); // we might need to flip this once robots set
    }
    if (m_intakeMode == IntakeMode.NOTHING) {
      m_intake.set(.0);
    }
    if (m_intakeMode == IntakeMode.OUTTAKING) {
      m_intake.set(-1);
    }

    if (m_joystick.getBButtonPressed()) {
      if (m_is_ramping == true) {
        m_is_ramping = false;
      } else if (m_is_ramping == false) {
        m_is_ramping = true;
      }
    }
    if (m_is_ramping) {
      m_ramp.set(1);
    } else {
      m_ramp.set(0);
    }

    if (m_joystick.getStartButtonReleased()) {
      m_is_backwards = !m_is_backwards;
    }
    if (m_joystick.getBackButtonReleased()) {
      m_is_turbo = !m_is_turbo;
    }

    double speed;
    if (m_is_backwards == true) {
      speed = 1;
    } else {
      speed = -1;
    }
    if (m_is_turbo == false) {
      speed = speed * .5;
    }

    double left_stick = m_joystick.getLeftY() * speed;
    double right_stick = m_joystick.getRightY() * speed;
    if (m_is_backwards == true) {
      m_robotDrive.tankDrive(right_stick, left_stick);
    } else {
      m_robotDrive.tankDrive(left_stick, right_stick);
    }

  }

  /** This function is called once each time the robot enters test mode. */
  @Override
  public void testInit() {
  }

  /** This function is called periodically during test mode. */
  @Override
  public void testPeriodic() {
  }
}
